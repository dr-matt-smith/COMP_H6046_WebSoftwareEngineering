<div><?php echo $message; ?></div>
