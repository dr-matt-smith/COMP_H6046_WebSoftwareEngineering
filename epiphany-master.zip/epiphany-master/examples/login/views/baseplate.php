<?php
  include_once "header.php";
  include_once $body;
  include_once "footer.php";
?>
